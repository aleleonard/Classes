# learn_chef_apache2

This basic cookbook configures Apache on Ubuntu.
